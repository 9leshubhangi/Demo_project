package Stringpgm;
import java.util.*;
public class strprgm {

	public static void main(String[] args) {
   System.out.println("Enter string : ");
   Scanner sc = new Scanner(System.in);
   String str = sc.nextLine();
//String str="lkkasgfhgfsaasahsfgfhgasghfhgfasgfshahjhjujujikikujuhyhghghgjujikajsjkjakjsujujhhjsjdhj";
System.out.println("total length : " +str.length());
int c = (str.split("as").length)-1;
// as,gf, hj,hg,kj,uj,sa
System.out.println(" total as : " + c);

  int c1 = (str.split("gf").length)-1;
//as,gf, hj,hg,kj,uj,sa
  System.out.println(" total gf : " + c1);
	
	int c2 = (str.split("hj").length)-1;
	// as,gf, hj,hg,kj,uj,sa
	System.out.println(" total hj : " + c2);
	 
	int c3 = (str.split("hg").length)-1;
	// as,gf, hj,hg,kj,uj,sa
	System.out.println(" total hg : " + c3);
	 
   int c4 = (str.split("kj").length)-1;
//as,gf, hj,hg,kj,uj,sa
   System.out.println(" total kj : " + c4);


   int c5 = (str.split("uj").length)-1;
//as,gf, hj,hg,kj,uj,sa
   System.out.println(" total uj : " + c5);

   int c6 = (str.split("sa").length)-1;
//as,gf, hj,hg,kj,uj,sa
  System.out.println(" total sa : " + c6);

	
	//////////////////////////////////////////////////////////////////////////////
  String s[] = str.split(" ");
    
      char[] ch = str.toCharArray();
	for(int i=0;i>= ch.length-1;i++) {
		int as_count = 1;
	for(int j = i+1; j < ch.length; j--) {
		
		if((s[i].equals(ch[j])) )
	{
	   as_count++;
	   s[j]="0";
		}
	
	}
	if(as_count > 1 && s[i] != "0")
		{
		System.out.println( s[i]);

		}

	}
}
}
	   
   
	


