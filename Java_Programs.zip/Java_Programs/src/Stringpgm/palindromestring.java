package Stringpgm;
import java.util.*;
public class palindromestring {
	public static void main(String[] args) {
				System.out.println("Enter String : ");
				Scanner sc =new Scanner(System.in);
				String s = sc.nextLine();
				System.out.println("Origanal String : " + s);
				System.out.println(" Length of given string : " + s.length());
				char ch[] = s .toCharArray();
				String rev ="";
		       for( int i = ch.length-1;i >= 0;i--)
		       {
		    	    rev = rev + ch[i];
		       }
		        System.out.println("reverse String : "  + rev );
			
             if( s.equals(rev))
             {
            System.out.println(" String is palindrome string ");	 
             }
             else
             {
            	 System.out.println("String is not palindrome ");
             }
		
	}
}


