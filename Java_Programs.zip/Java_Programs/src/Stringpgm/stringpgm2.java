package Stringpgm;
import java .uti.*;
public class stringpgm2 {

	public static void main(String[] args) {

	}
}
