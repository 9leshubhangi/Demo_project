package Stringpgm;
import java.util.*;
public class reversestring {

	public static void main(String[] args) {
		System.out.println("Enter String : ");
		Scanner sc =new Scanner(System.in);
		String s = sc.nextLine();
		System.out.println("Origanal String : " + s);
		char ch[] = s .toCharArray();
		String rev = " ";
       for( int i = ch.length-1;i >= 0;i--)
       {
    	    rev = rev + ch[i];
       }
       System.out.println(" Length of given string : " + s.length());
       System.out.println("reverse String : "  + rev );
	}

}
