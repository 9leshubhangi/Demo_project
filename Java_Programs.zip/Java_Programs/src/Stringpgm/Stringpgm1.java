package Stringpgm;
import java.util.Scanner;
public class Stringpgm1 {

	public static void main(String[] args) {
	System.out.println("enter  first String : ");
	Scanner sc = new Scanner(System.in);
	String s = sc.nextLine();
	System.out.println("enter  next string : ");
	String s1 = sc.nextLine();
	
	 s = s.replace('o', 'a');
	 System.out.println("repalaced character new string : " + s);
	 
	 String s2 = s.substring(0,5);
	String s3 = s1.substring(0,3);
	 System.out.println(s2);
	 System.out.println(s3);
	 System.out.println(" new string : " + (s2+s3));
	 
	 System.out.println("length of s string  : " + s.length());
     System.out.println("length of s1 string  : " + s1.length());
     
	}
	}
