package Stringpgm;
import java.util.*;
public class reversenumber {

	public static void main(String[] args) {
		int rev=0;
		System.err.println("enter number : ");
		Scanner sc = new Scanner(System.in);
		int  n = sc.nextInt();
	    System.out.println("Original Number: " + n);
	    int  r = n;
	  while(n != 0) {
		  int  rem = n % 10;
	    	   rev = rev * 10 + rem ;
				n /= 10;
			    }

			    System.out.println("Reversed Number: " + rev);
			  }
			

	}


