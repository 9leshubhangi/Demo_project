package Stringpgm;
import java.util.*;
public class somestringmethod {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println(" enter   1 St string :");
		String s = sc.nextLine();
		System.out.println(" Enetr 2 nd string  : ");
		String s1 =sc.nextLine();
		System.out.println("enter 3 rd string : ");
		String s2 = sc.nextLine();
		
		System.out.println("length of  1st string :" + s.length());
		System.out.println("length of  2 nd string :" + s1.length());
		System.out.println("length of  3 rd string :" + s2.length());
		
		String s3 = s.replace("angi","dip");
		System.out.println("character replaced String  :" +s3);
		System.out.println("uppercase string : " + s3.toUpperCase());
		System.out.println("Lowercase string  :" + s3.toLowerCase());
		System.out.println(s3.trim());
		
		System.out.println(" String start with s : " + s.startsWith("s"));
		System.out.println(" String end with i:" + s1.endsWith("i"));
		
		System.out.println(" current character :" +s1.charAt(2));
				}

}
