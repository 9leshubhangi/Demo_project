package Shubhi;

import java.util.ArrayList;

class Man
{
	int age;
	String name;
	String work;
	Man(String name,int age,String work)
	{
	this.name = name;
	this. age = age;
	this.work=work;
	Man m1 = new Man("Vitthal",56,"farmer");
	Man m2 = new Man(" Kamal", 45,"housewife");
	Man m3 = new Man(" Dipak", 30, "job");
	Man m4 = new Man("Shubhangi", 22,"student");
	ArrayList<Man> al=new ArrayList<Man>();  
	  al.add(m1);//adding Student class object  
	  al.add(m2);  
	  al.add(m3);  
	  al.add(m4);
	 Iterator itr=al.iterator();  
while(itr.hasNext()){  
  Man st=(Man)itr.next();  
  System.out.println(st.name+" "+st.age+" "+st.work);  
}  
}  
} 
  
