package Shubhi;
import java.util.Scanner;
public class fibonaccinumber {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter value for n = ");
		 int n =s.nextInt();
	      int  a = 0, b = 1;
			    System.out.println("Fibonacci Series : " + n);

			    for (int i = 1; i <= n; ++i) {
			      System.out.print(a + ", ");
			      int c = a + b;
			      a = b;
			      b = c;
			    }
			  }
			}
	


