package Shubhi;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;

public class Gaibani_Shubhi {

	public static void main(String[] args) {
		
		HashMap<String, String> str=new HashMap<>();
		str.put("Name :", "Dipak vitthal navale");
		str.put("Age : ", "30");
		str.put("Profession :","QA");
	    System.out.println(str);		
		
		HashMap<String, String> str1=new HashMap<>();
		str1.put("Name : ", "vitthal Yashwant navale");
		str1.put("Age : ", "60");
		str1.put("Profession : ", "Farmer");
		System.out.println(str1);
		
		HashMap<String, String> str2=new HashMap<>();
		str2.put("Name : ", "kamal Yashwant navale");
		str2.put("Age : ", "52");
		str2.put("Profession : ", "housewife");
		
		System.out.println(str2);
		
		HashMap<String, String> str3=new HashMap<>();
		str3.put("Name : ", "Shubhangi Dipak Navale");
		str3.put("Age : ", "22");
		str3.put("Profession : ", "student");
		System.out.println(str3);
		
		HashMap<String, String> str4=new HashMap<>();
		str4.put("Name : ", "Shobha Maruti Bansode");
		str4.put("Age : ", "17");
		str4.put("Profession : ", "student");
		System.out.println(str4);
		
		HashMap<String, String> str5=new HashMap<>();
		str5.put("Name : ", "Ganesh Maruti Bansode");
		str5.put("Age : ", "15");
		str5.put("Profession : ", "student");
		System.out.println(str5);
		
		HashMap<String, String> str6=new HashMap<>();
		str6.put("Name: ", "Kalyani Maruti Bansode");
		str6.put("Age: ", "12");
        str6.put("Profession: ", "student"); 
        System.out.println(str6);
	}
	
	
}
