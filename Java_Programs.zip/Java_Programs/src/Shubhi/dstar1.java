package Shubhi;
import java.util.*;
public class dstar1 {

	public static void main(String[] args) 
		 {
		      Scanner scan = new Scanner(System.in);
		      int n = 0;
		      System.out.print("Enter N value:: ");
		      n = scan.nextInt();
		      printStarHalfDiamond(n);
		   }

		   private static void printStarHalfDiamond(int n) {
		      if(n <= 0)
		      System.out.println("Enter Positive Number");

		     
		      int star = 0;

		      for(int i=1; i < 2*n; i++) {
		         if(i < n) star = i;
		         else star = Math.abs(2*n - i);

		       
		         for(int j = 1; j <= star; j++) {
		            System.out.print("*");
		         }

		     
		         System.out.println();
		      }
	}
}
