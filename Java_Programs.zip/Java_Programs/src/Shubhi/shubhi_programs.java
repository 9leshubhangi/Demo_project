package Shubhi;

public class shubhi_programs {

	public static void main(String[] args) {		
		String p = " ";      
		for (int i = 1; i <= 1000; i++)         
		       { 		  	  
		          int c=0; 	  
		          for(int n =i; n>=1; n--)
			  {
		             if(i%n==0)
			     {
		 		c = c + 1;
			     }
			  }
			  if (c ==2)
			  {
			     p = p + i +  " ";
			  }	
		       }	
		       System.out.println("Prime numbers from 1 to 1000 are :");
		       System.out.println(p);
		   }
		}
