package Shubhi;
import java.awt.*;
public class dpgm74 {

	public static void main(String[] args) {
		dpgm()
		{
			Butto
		}

	}

}
