package Shubhi;
import java.util.*;
public class substringpgm {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter String : ");
		String str = sc.nextLine();
		String str1 = str.substring(3,5);
		System.out.println(str1);

	}

}
