package Shubhi;

public class oddeven {
	public static void main(String[] arg) {
		for (int n = 0; n <= 1000; n++) {
			if (n % 2 == 0) {
				if (n <= 9) {
					System.out.print(" even number= 00" + n);
				} else if (n <= 99 && n >= 10) {
					System.out.print(" even number= 0" + n);
				} else if (n <= 999 && n >= 100) {
					System.out.print(" even number= " + n);
				} else {
					System.out.print(" even number= " + n);
				}
			} else {
				if (n <= 9) {
					System.out.println("       odd number= 00" + n);
				} else if (n <= 99 && n >= 10) {
					System.out.println("       odd number= 0" + n);
				} else if (n <= 999 && n >= 100) {
					System.out.println("       odd number= " + n);
				} else {
					System.out.print("         odd number= " + n);
				}

			}
		}
	}
}