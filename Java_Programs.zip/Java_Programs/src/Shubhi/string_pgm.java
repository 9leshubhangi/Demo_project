package Shubhi;

public class string_pgm {

	public static void main(String[] args) {
		String s = "Shubhangi Bansode";
		String s1 ="Dipak Navale";
		System.out.println(s);
		System.out.println(s1);
		
		String s2 = s.concat(s1);
		System.out.println(s2);
		
		String s3 =s1.replace(s,s2);
		System.out.println(s3);
		
		String s4 =s.repeat(2);
		System.out.println(s4);
		
		String s5 = s1.strip();
		System.out.println(s5);
		
		String str = s.substring(0, 10);
		System.out.println(str);
		
		String t = str.intern();
		System.out.println(t);
						          
        String y = s.concat(s2);
        System.out.println(y);
        
                     
	}
}
