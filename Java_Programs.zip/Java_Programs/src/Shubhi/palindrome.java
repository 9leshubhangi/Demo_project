package Shubhi;
import java.util.Scanner;
public class palindrome {

	public static void main(String[] args) {
	int r,s = 0,t;	
	System.out.println("enter number : ");
	Scanner sc = new Scanner(System.in);
	int n =sc.nextInt();
	t = n;
	while(n>0)
	{
	r = n % 10;
	s = (s*10)+r;
	n = n/10;
	}
      if(t == s)
      {
            System.out.println(" given number is palindrome  number : " + t);
      }
      else
      {
    	  System.out.println(" given number is not palindrome number : " + t);
      }
    	  
}
}
