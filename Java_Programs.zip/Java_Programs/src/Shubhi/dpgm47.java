package Shubhi;

public class dpgm47{

	public static void main(String[] args) {
		dpgm47()
		{
			System.out.println("constru is created ");
		}
	}

}
