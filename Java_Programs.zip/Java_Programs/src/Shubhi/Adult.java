package Shubhi;

import java.util.Scanner;

public class Adult {

	public static void main(String[] args) {
		for (int i = 0; i <= 1000; i++) {
			System.out.println("enter your age = ");
			Scanner s = new Scanner(System.in);
			double age = s.nextDouble();
		if(age >= 18)
		{
    		System.out.println("you are Adult");
			}
		else 
			{
				System.out.println("you are not Adult");
			} 
		}
	}
}
