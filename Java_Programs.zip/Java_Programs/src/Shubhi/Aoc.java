package Shubhi;
import java.util.*;
public class Aoc {

	public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);
     System.out.println("enter value for  r : ");
     double r = sc.nextDouble();
    double r1 = 3.14 * r * r;
    System.out.println("Area of circle : " + r1);
	}

}
