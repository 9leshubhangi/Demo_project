package Shubhi;
	import java.util.*;  
	class Info {  
	int age;  
	String name,work;  
	int quantity;  
	public Info(int age, String name, String work) {  
	    this.age = age;  
	    this.name = name;  
	    this.work = work;    
	}  
	}  
	public class ArrayListExample20 {  
	public static void main(String[] args) {  
	     
	    List<Info> list=new ArrayList<Info>();  
	    Info b1=new Info(56,"Vitthal Navale","farmer");  
	    Info b2=new Info(45,"Kamal Navale","housewife");  
	    Info b3=new Info(30,"Dipak Navale","job");
	    Info b4 = new Info(22,"Shubhanngi Navale","student");
	   
	    list.add(b1);  
	    list.add(b2);  
	    list.add(b3);
	    list.add(b4);	  
	    for(Info b:list){  
	        System.out.println(b.name+" "+b.age+" "+b.work);  
	    }  
	}  
	
	pub

}
