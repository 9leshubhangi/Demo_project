package Shubhi;
import java.util.Scanner;
public class leapyear {

	public static void main(String[] args) {
		System.out.println("Enter year = ");
		Scanner s =new Scanner(System.in);
		int y = s.nextInt();
		if(y %4 == 0)
		{
			System.out.println( "entered year is leap year : " + y );
		}
		else
		{
			System.out.println("entered year is not leap year : " + y);
		}
		
	}

}
