package Shubhi;
import java.util.*;
public class Aor {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println(" enter  value for l : ");
		double l = sc.nextDouble();
		System.out.println("enter value for b : ");
	    double b = sc.nextDouble();
	    double aor = l * b ;
	    System.out.println(" Area of Reactangle : " + aor);
	}

}
