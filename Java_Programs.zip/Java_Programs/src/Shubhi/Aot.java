package Shubhi;
import java.util.*;
public class Aot {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println(" enter value for b :");
		double b = sc.nextDouble();
		System.out.println("enter value for h : ");
		double h = sc.nextDouble();
		double aot = ( b* h)/2;  
		System.out.println("Area of triangle : " + aot );
	}
}
