package Shubhi;
import java.util.Scanner;

class simple_calculator {

	public static void main(String[] args) 
	{
		char op;
	    Double n1, n2, r;

	    Scanner input = new Scanner(System.in);
	    
	    System.out.println("Choose an operator: +, -, *, /,or %");
	    op = input.next().charAt(0);

	    System.out.println("Enter first number = ");
	    n1 = input.nextDouble();

	    System.out.println("Enter second number = ");
	    n2 = input.nextDouble();

	    switch (op) {

	     case '+':
	        r = n1 + n2;
	        System.out.println("Addition is =" + r);
	        break;

	     case '-':
	        r = n1 - n2;
	        System.out.println("subtraction is = " + r);
	        break;

	     case '*':
	        r = n1 * n2;
	        System.out.println("multiplication is  = " + r);
	        break;
	     case '/':
	        r = n1 / n2;
	        System.out.println("division is = " + r);
	        break;
	        

	     case '%':
	        r = n1 % n2;
	        System.out.println("module is  = " + r);
	        break;

	      default:
	        System.out.println("Invalid operator!");
	        break;
	    }

	}

}
